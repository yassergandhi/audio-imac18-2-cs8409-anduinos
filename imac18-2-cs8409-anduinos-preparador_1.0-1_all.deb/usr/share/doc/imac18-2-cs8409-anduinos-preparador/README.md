# CS8409: AnduinOS 2.0.6 / iMac18,2 / kernel 7.0.0-44-generic

Este .deb **NO contiene un módulo de kernel precompilado**. Instala un preparador que
descarga una versión fijada del proyecto armin-haghi/imac-cs8409-linux-audio
(commit b08d0745e1b78d6949d5a231d91351e73ddf8079), examina la máquina y valida
la compatibilidad ABI (BTF) antes de crear o instalar el paquete real del controlador.

El código procede de un proyecto probado en iMac18,3 con Ubuntu 7.0.0-30;
NO se ha demostrado todavía su funcionamiento en iMac18,2 / AnduinOS 2.0.6 / 7.0.0-44.
El hardware Apple con CS8409 es compatible conceptualmente, pero la verificación ABI
es necesaria y no garantiza por sí sola audio físico ni ausencia de errores.

Comandos:
    sudo apt update
    sudo apt install linux-headers-$(uname -r)
    sudo apt install ./imac18-2-cs8409-anduinos-preparador_1.0-1_all.deb
    imac-cs8409-anduinos diagnostico
    imac-cs8409-anduinos construir
    sudo apt install ~/Downloads/snd-hda-codec-cs8409-apple-dkms_0.1+gitb08d074-1_all.deb
    sudo reboot

Como alternativa a construir e instalar por separado:
    imac-cs8409-anduinos instalar

Si falla la verificación ABI, NO anularla: detén la instalación.
El módulo es externo, no firmado y sustituye la selección del controlador
integrado para CS8409. No reinicia automáticamente.

Verificación:
    modinfo -n snd_hda_codec_cs8409
    dkms status
    speaker-test -c2 -twav -l1 -D default

Desinstalación:
    sudo apt remove snd-hda-codec-cs8409-apple-dkms
    sudo reboot

Recuperación si el arranque queda detenido:
  En el menú de GRUB, edita temporalmente la entrada con la tecla e, añade
  modprobe.blacklist=snd_hda_codec_cs8409 a la línea que comienza por linux,
  y arranca con Ctrl+X. Luego retira el paquete DKMS y reinicia.
  El acceso a GRUB puede variar con el firmware EFI de Apple.

Fuentes:
- https://github.com/armin-haghi/imac-cs8409-linux-audio
- https://github.com/nullaroni/imac-cs8409 (fuente usada por el kit del usuario;
  no se emplea aquí porque falta una verificación ABI frente a Ubuntu 7.0)
